class Movie {
  final int id;
  final String title;
  final String posterURL;
  final String imdbId;

  Movie({
    required this.id,
    required this.title,
    required this.posterURL,
    required this.imdbId,
  });

  factory Movie.fromJson(Map<String, dynamic> json) {
    return Movie(
      id: json['id'] is int
          ? json['id']
          : int.tryParse(json['id']?.toString() ?? '') ?? 0,
      title: json['title']?.toString() ?? 'Tanpa Judul',
      posterURL: json['posterURL']?.toString() ?? 'N/A',
      imdbId: json['imdbId']?.toString() ?? '-',
    );
  }

  bool get hasPoster =>
      posterURL.isNotEmpty &&
      posterURL != 'N/A' &&
      posterURL.startsWith('http') &&
      (posterURL.endsWith('.jpg') ||
          posterURL.endsWith('.jpeg') ||
          posterURL.endsWith('.png') ||
          posterURL.contains('media-amazon'));
}

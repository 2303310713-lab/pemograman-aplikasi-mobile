import 'package:flutter/material.dart';

class ProfilPage extends StatelessWidget {
  const ProfilPage({super.key});

  static const String nama = 'Grace Putri Natalia Panjaitan';
  static const String nim = '2303310713';
  static const String kelas = 'IF - C SIANG';
  static const String prodi = 'S-1 Informatika';
  static const String matkul = 'Pemrograman Aplikasi Mobile ';
  static const String dosen = 'Alwin Fau, S.Kom., M.Kom.';

  static const Color bgColor = Color(0xFF0B0B0F);
  static const Color surfaceColor = Color(0xFF1A1315);
  static const Color accentRed = Color(0xFFB3122D);
  static const Color accentAmber = Color(0xFFE8A33D);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: bgColor,
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Center(
            child: Column(
              children: [
                Container(
                  width: 104,
                  height: 104,
                  padding: const EdgeInsets.all(3),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(
                      colors: [accentRed, accentAmber],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: accentRed.withOpacity(0.35),
                        blurRadius: 22,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: Container(
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: bgColor,
                    ),
                    child: const Icon(
                      Icons.person,
                      color: Colors.white,
                      size: 46,
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                const Text(
                  nama,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 19,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 6),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 5,
                  ),
                  decoration: BoxDecoration(
                    color: accentAmber.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: accentAmber.withOpacity(0.35)),
                  ),
                  child: Text(
                    'NIM: $nim',
                    style: const TextStyle(
                      color: accentAmber,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 32),
          Row(
            children: [
              Container(
                width: 4,
                height: 16,
                decoration: BoxDecoration(
                  color: accentAmber,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(width: 10),
              const Text(
                'DETAIL IDENTITAS',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.1,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          _ProfileTile(icon: Icons.badge_outlined, label: 'NIM', value: nim),
          _ProfileTile(
            icon: Icons.school_outlined,
            label: 'Program Studi',
            value: prodi,
          ),
          _ProfileTile(
            icon: Icons.groups_outlined,
            label: 'Kelas',
            value: kelas,
          ),
          _ProfileTile(
            icon: Icons.menu_book_outlined,
            label: 'Mata Kuliah',
            value: matkul,
          ),
          _ProfileTile(
            icon: Icons.person_search_outlined,
            label: 'Dosen Penguji',
            value: dosen,
          ),
          _ProfileTile(
            icon: Icons.apartment_outlined,
            label: 'Fakultas',
            value: 'Teknologi dan Ilmu Komputer',
          ),
        ],
      ),
    );
  }
}

class _ProfileTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _ProfileTile({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: ProfilPage.surfaceColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.05)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(9),
            decoration: BoxDecoration(
              color: ProfilPage.accentRed.withOpacity(0.14),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: ProfilPage.accentAmber, size: 18),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: const TextStyle(color: Colors.white38, fontSize: 11),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

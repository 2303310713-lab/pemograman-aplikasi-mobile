import 'package:flutter/material.dart';

class PesanPage extends StatelessWidget {
  const PesanPage({super.key});

  static const Color bgColor = Color(0xFF0B0B0F);
  static const Color surfaceColor = Color(0xFF1A1315);
  static const Color accentAmber = Color(0xFFE8A33D);

  @override
  Widget build(BuildContext context) {
    final List<String> pesanKosong = List.generate(6, (_) => '');

    return Container(
      color: bgColor,
      child: pesanKosong.isEmpty
          ? const _EmptyPesan()
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: pesanKosong.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, index) {
                return Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 16,
                  ),
                  decoration: BoxDecoration(
                    color: surfaceColor,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.white.withOpacity(0.05)),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: accentAmber.withOpacity(0.1),
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: accentAmber.withOpacity(0.25),
                          ),
                        ),
                        child: const Icon(
                          Icons.person_outline,
                          color: Colors.white38,
                          size: 20,
                        ),
                      ),
                      const SizedBox(width: 14),
                      const Expanded(
                        child: Text(
                          'No. Message',
                          style: TextStyle(
                            color: Colors.white38,
                            fontStyle: FontStyle.italic,
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }
}

class _EmptyPesan extends StatelessWidget {
  const _EmptyPesan();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.mail_outline, color: Colors.white24, size: 48),
          SizedBox(height: 12),
          Text(
            'No. Message',
            style: TextStyle(color: Colors.white38, fontSize: 14),
          ),
        ],
      ),
    );
  }
}

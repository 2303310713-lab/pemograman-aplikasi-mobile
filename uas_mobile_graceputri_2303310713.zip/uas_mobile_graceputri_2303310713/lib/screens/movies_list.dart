import 'package:flutter/material.dart';
import '../models/movie.dart';
import '../services/movie_service.dart';
import '../services/riwayat_service.dart';

class MoviesListPage extends StatefulWidget {
  const MoviesListPage({super.key});

  @override
  State<MoviesListPage> createState() => _MoviesListPageState();
}

class _MoviesListPageState extends State<MoviesListPage> {
  final MovieService _movieService = MovieService();
  late Future<List<Movie>> _futureMovies;

  static const Color bgColor = Color(0xFF0B0B0F);
  static const Color surfaceColor = Color(0xFF1A1315);
  static const Color accentRed = Color(0xFFB3122D);
  static const Color accentAmber = Color(0xFFE8A33D);

  @override
  void initState() {
    super.initState();
    _futureMovies = _movieService.fetchMovies();
  }

  Future<void> _refresh() async {
    setState(() {
      _futureMovies = _movieService.fetchMovies();
    });
    await _futureMovies;
  }

  void _onMovieTap(Movie movie) {
    RiwayatService.instance.tambahKeRiwayat(movie);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: surfaceColor,
        duration: const Duration(milliseconds: 900),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: accentAmber.withOpacity(0.3)),
        ),
        content: Row(
          children: [
            const Icon(Icons.check_circle, color: accentAmber, size: 18),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                '"${movie.title}" ditambahkan ke Riwayat',
                style: const TextStyle(color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );

    showModalBottomSheet(
      context: context,
      backgroundColor: surfaceColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) => _MovieDetailSheet(movie: movie),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: bgColor,
      child: FutureBuilder<List<Movie>>(
        future: _futureMovies,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(color: accentAmber),
            );
          }

          if (snapshot.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: surfaceColor,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Colors.white.withOpacity(0.06)),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.wifi_off,
                        color: Colors.white38,
                        size: 40,
                      ),
                      const SizedBox(height: 12),
                      Text(
                        'Gagal memuat data movies.\n${snapshot.error}',
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Colors.white54),
                      ),
                      const SizedBox(height: 18),
                      ElevatedButton.icon(
                        onPressed: _refresh,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: accentRed,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(
                            horizontal: 20,
                            vertical: 12,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        icon: const Icon(Icons.refresh, size: 18),
                        label: const Text('Coba Lagi'),
                      ),
                    ],
                  ),
                ),
              ),
            );
          }

          final movies = snapshot.data ?? [];

          if (movies.isEmpty) {
            return const Center(
              child: Text(
                'Data movies tidak ditemukan.',
                style: TextStyle(color: Colors.white54),
              ),
            );
          }

          return RefreshIndicator(
            color: accentAmber,
            backgroundColor: surfaceColor,
            onRefresh: _refresh,
            child: GridView.builder(
              padding: const EdgeInsets.all(16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 16,
                crossAxisSpacing: 16,
                childAspectRatio: 0.62,
              ),
              itemCount: movies.length,
              itemBuilder: (context, index) {
                final movie = movies[index];
                return _MovieCard(
                  movie: movie,
                  surfaceColor: surfaceColor,
                  accentAmber: accentAmber,
                  onTap: () => _onMovieTap(movie),
                );
              },
            ),
          );
        },
      ),
    );
  }
}

class _MovieCard extends StatelessWidget {
  final Movie movie;
  final Color surfaceColor;
  final Color accentAmber;
  final VoidCallback onTap;

  const _MovieCard({
    required this.movie,
    required this.surfaceColor,
    required this.accentAmber,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      splashColor: accentAmber.withOpacity(0.15),
      onTap: onTap,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: Stack(
          fit: StackFit.expand,
          children: [
            movie.hasPoster
                ? Image.network(
                    movie.posterURL,
                    fit: BoxFit.cover,
                    loadingBuilder: (context, child, progress) {
                      if (progress == null) return child;
                      return Container(
                        color: surfaceColor,
                        child: Center(
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: accentAmber,
                          ),
                        ),
                      );
                    },
                    errorBuilder: (context, error, stack) => _PosterFallback(
                      title: movie.title,
                      surfaceColor: surfaceColor,
                    ),
                  )
                : _PosterFallback(
                    title: movie.title,
                    surfaceColor: surfaceColor,
                  ),
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: Container(
                padding: const EdgeInsets.fromLTRB(10, 26, 10, 10),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      Colors.black.withOpacity(0.92),
                    ],
                  ),
                ),
                child: Text(
                  movie.title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                    fontSize: 12.5,
                  ),
                ),
              ),
            ),
            Positioned(
              top: 8,
              right: 8,
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.55),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.play_arrow_rounded,
                  color: Colors.white,
                  size: 16,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PosterFallback extends StatelessWidget {
  final String title;
  final Color surfaceColor;
  const _PosterFallback({required this.title, required this.surfaceColor});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      color: surfaceColor,
      alignment: Alignment.center,
      padding: const EdgeInsets.all(8),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.movie_outlined, color: Colors.white38, size: 32),
          const SizedBox(height: 6),
          Text(
            title,
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: Colors.white38, fontSize: 11),
          ),
        ],
      ),
    );
  }
}

class _MovieDetailSheet extends StatelessWidget {
  final Movie movie;
  const _MovieDetailSheet({required this.movie});

  static const Color accentRed = Color(0xFFB3122D);
  static const Color accentAmber = Color(0xFFE8A33D);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              margin: const EdgeInsets.only(bottom: 20),
              decoration: BoxDecoration(
                color: Colors.white24,
                borderRadius: BorderRadius.circular(4),
              ),
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: SizedBox(
                    width: 90,
                    height: 130,
                    child: movie.hasPoster
                        ? Image.network(movie.posterURL, fit: BoxFit.cover)
                        : _PosterFallback(
                            title: movie.title,
                            surfaceColor: const Color(0xFF241A1D),
                          ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        movie.title,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: accentRed.withOpacity(0.18),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: accentRed.withOpacity(0.5)),
                        ),
                        child: const Text(
                          'Horror',
                          style: TextStyle(
                            color: accentAmber,
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        'IMDB ID: ${movie.imdbId}',
                        style: const TextStyle(
                          color: Colors.white54,
                          fontSize: 12.5,
                        ),
                      ),
                      const SizedBox(height: 14),
                      Row(
                        children: const [
                          Icon(
                            Icons.check_circle,
                            color: accentAmber,
                            size: 16,
                          ),
                          SizedBox(width: 6),
                          Text(
                            'Ditambahkan ke Riwayat',
                            style: TextStyle(color: accentAmber, fontSize: 12),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

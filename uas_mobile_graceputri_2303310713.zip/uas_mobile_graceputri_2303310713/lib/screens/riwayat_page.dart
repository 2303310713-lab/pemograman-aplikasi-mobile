import 'package:flutter/material.dart';
import '../services/riwayat_service.dart';

class RiwayatPage extends StatefulWidget {
  const RiwayatPage({super.key});

  @override
  State<RiwayatPage> createState() => _RiwayatPageState();
}

class _RiwayatPageState extends State<RiwayatPage> {
  final RiwayatService _riwayatService = RiwayatService.instance;

  static const Color bgColor = Color(0xFF0B0B0F);
  static const Color surfaceColor = Color(0xFF1A1315);
  static const Color accentRed = Color(0xFFB3122D);
  static const Color accentAmber = Color(0xFFE8A33D);

  @override
  void initState() {
    super.initState();
    _riwayatService.addListener(_onRiwayatChanged);
  }

  @override
  void dispose() {
    _riwayatService.removeListener(_onRiwayatChanged);
    super.dispose();
  }

  void _onRiwayatChanged() {
    if (mounted) setState(() {});
  }

  String _formatWaktu(DateTime waktu) {
    final jam = waktu.hour.toString().padLeft(2, '0');
    final menit = waktu.minute.toString().padLeft(2, '0');
    final detik = waktu.second.toString().padLeft(2, '0');
    return '$jam:$menit:$detik';
  }

  @override
  Widget build(BuildContext context) {
    final riwayat = _riwayatService.riwayat;

    return Container(
      color: bgColor,
      child: riwayat.isEmpty
          ? const _EmptyRiwayat()
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                  child: Row(
                    children: [
                      Container(
                        width: 4,
                        height: 16,
                        decoration: BoxDecoration(
                          color: accentAmber,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          '${riwayat.length} film pernah dibuka',
                          style: const TextStyle(
                            color: Colors.white54,
                            fontSize: 12,
                          ),
                        ),
                      ),
                      TextButton.icon(
                        onPressed: () => _riwayatService.hapusRiwayat(),
                        style: TextButton.styleFrom(foregroundColor: accentRed),
                        icon: const Icon(Icons.delete_outline, size: 16),
                        label: const Text('Hapus semua'),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: ListView.separated(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: riwayat.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (context, index) {
                      final item = riwayat[index];
                      return Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: surfaceColor,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: Colors.white.withOpacity(0.05),
                          ),
                        ),
                        child: Row(
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(10),
                              child: SizedBox(
                                width: 50,
                                height: 70,
                                child: item.movie.hasPoster
                                    ? Image.network(
                                        item.movie.posterURL,
                                        fit: BoxFit.cover,
                                        errorBuilder: (c, e, s) => Container(
                                          color: const Color(0xFF241A1D),
                                          child: const Icon(
                                            Icons.movie,
                                            color: Colors.white38,
                                            size: 18,
                                          ),
                                        ),
                                      )
                                    : Container(
                                        color: const Color(0xFF241A1D),
                                        child: const Icon(
                                          Icons.movie,
                                          color: Colors.white38,
                                          size: 18,
                                        ),
                                      ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    item.movie.title,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w600,
                                      fontSize: 13,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    'Diklik pukul ${_formatWaktu(item.waktuKlik)}',
                                    style: const TextStyle(
                                      color: Colors.white38,
                                      fontSize: 11,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.all(7),
                              decoration: BoxDecoration(
                                color: accentAmber.withOpacity(0.12),
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(
                                Icons.history,
                                color: accentAmber,
                                size: 16,
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
    );
  }
}

class _EmptyRiwayat extends StatelessWidget {
  const _EmptyRiwayat();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.history_toggle_off, color: Colors.white24, size: 48),
          const SizedBox(height: 12),
          const Text(
            'Belum ada riwayat',
            style: TextStyle(color: Colors.white70, fontSize: 14),
          ),
          const SizedBox(height: 4),
          const Text(
            'Buka tab Movies dan tap salah satu film',
            style: TextStyle(color: Colors.white38, fontSize: 12),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import '../models/movie.dart';

// Menyimpan satu entri riwayat: movie apa yang diklik dan kapan.
class RiwayatItem {
  final Movie movie;
  final DateTime waktuKlik;

  RiwayatItem({required this.movie, required this.waktuKlik});
}

// Service sederhana (Singleton + ChangeNotifier) yang menjembatani
// halaman Movies (tempat item diklik) dengan halaman Riwayat
// (tempat riwayat item yang diklik ditampilkan), sesuai soal nomor 4.
//
// Karena Home, Riwayat, Movies, Pesan, Profil berada dalam satu
// IndexedStack di MainScreen, cukup 1 instance service ini yang
// hidup selama aplikasi berjalan (tidak perlu package tambahan
// seperti provider).
class RiwayatService extends ChangeNotifier {
  RiwayatService._internal();
  static final RiwayatService instance = RiwayatService._internal();

  final List<RiwayatItem> _riwayat = [];

  List<RiwayatItem> get riwayat => List.unmodifiable(_riwayat.reversed);

  void tambahKeRiwayat(Movie movie) {
    _riwayat.add(RiwayatItem(movie: movie, waktuKlik: DateTime.now()));
    notifyListeners();
  }

  void hapusRiwayat() {
    _riwayat.clear();
    notifyListeners();
  }
}

import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/movie.dart';

// Service khusus untuk mengambil data movies dari API sesuai soal nomor 5.
class MovieService {
  static const String _baseUrl = 'https://api.sampleapis.com/movies/horror';

  Future<List<Movie>> fetchMovies() async {
    final response = await http.get(Uri.parse(_baseUrl));

    if (response.statusCode == 200) {
      final List<dynamic> data = jsonDecode(response.body);
      return data
          .map((item) => Movie.fromJson(item as Map<String, dynamic>))
          .toList();
    } else {
      throw Exception(
        'Gagal mengambil data movies (status: ${response.statusCode})',
      );
    }
  }
}

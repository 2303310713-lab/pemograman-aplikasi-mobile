import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';

void main() {
  runApp(const UasMobileApp());
}

class UasMobileApp extends StatelessWidget {
  const UasMobileApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'UAS Mobile - Movies Horror',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF14111F),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF6C3AE0),
          brightness: Brightness.dark,
        ),
        fontFamily: 'Roboto',
      ),

      home: const SplashScreen(),
    );
  }
}
